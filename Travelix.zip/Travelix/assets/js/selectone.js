$(document).ready(function() {
    $("#clickMore").click(function() {
        $("#hiddenFac").toggle();
    });
    $("#clickMore1").click(function() {
        $("#hiddenFac1").toggle();
    });
    $("#clickMore2").click(function() {
        $("#hiddenFac2").toggle();
    });
    $("#clickMore3").click(function() {
        $("#hiddenFac3").toggle();
    });
    $("#clickMore4").click(function() {
        $("#hiddenFac4").toggle();
    });
    $("#clickMore5").click(function() {
        $("#hiddenFac5").toggle();
    });
    $("#clickMore6").click(function() {
        $("#hiddenFac6").toggle();
    });
    $("#clickMore7").click(function() {
        $("#hiddenFac7").toggle();
    });
    $("#clickMore8").click(function() {
        $("#hiddenFac8").toggle();
    });
    $("#clickMore9").click(function() {
        $("#hiddenFac9").toggle();
    });
    $("#clickMore10").click(function() {
        $("#hiddenFac10").toggle();
    });
    $("#clickMore11").click(function() {
        $("#hiddenFac11").toggle();
    });
    $("#clickMore12").click(function() {
        $("#hiddenFac12").toggle();
    });
});